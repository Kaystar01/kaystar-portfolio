import React from 'react'

export default function Portfolio() {
  return (
    <div style={{ padding: '2rem', fontFamily: 'Arial' }}>
      <h1>Hello, I'm Kaystar</h1>
      <p>This is my portfolio site.</p>
    </div>
  )
}